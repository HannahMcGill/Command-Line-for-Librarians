🧭  02) Download Catalogue Records
====================================
🏆 Goal: Use curl to fetch a batch of Open Library records (JSON) and save them locally.

1️⃣ Type cd .. to return to the CL_2 parent folder

2️⃣ Type mkdir catalogue_project

💡 Why: mkdir means "make directory". You can use this command to create a new folder that will be called whatever name you indicate after the mkdir command (in this case "catalogue_project").

✨ Tip: Confirm that the catalogue_project has been created by typing ls

3️⃣ Navigate to the catalogue_project folder using cd and the tab key.

4️⃣ Fetch 50 records about gardening from Open Library by inputting the command line:  
curl -s "https://openlibrary.org/search.json?q=subject:gardening&limit=50" > records.json

💡 Why: This command line downloads metadata for 50 records about gardening from Open Library and saves it as a JSON file called records.json.

✨ Tip: To better understand how this command works, let's break it down piece by piece:

👉 curl is command‑line tool that gets data from the internet (think “download something from a URL”).

👉 -s means "silent" and works to hide progress messages so the terminal doesn’t get cluttered.

👉 "https://openlibrary.org/search.json" points to the Open Library API, which returns data instead of a webpage.

👉 "?q=subject:gardening&limit=50" is the query string, which asks the API to return books whose subject is gardening and limit the results to 50.

👉 "> records.json" means “save the result into a file titled records.json". Without this part of the command, the data would just appear in the terminal window.

👉 When you put all these pieces together, you end up with a new file in your current folder titled "records.json" that contains catalogue records for 50 books from Open Library.

5️⃣ To verify the file exists, type ls and make sure you see records.json

6️⃣ To verify that the file is populated with JSON catalogue records, type: head -n 10 records.json

💡 Why: head -n 10 records.json prints the first 10 lines of the file records.json to the terminal. 

✨ Tip: The head command is used to quickly preview the beginning of a file without opening the whole thing. The -n command indicates how many lines of the file to display.

🚀 TO GET TO THE NEXT LESSON: 

1️⃣ Type cd .. to return to the parent folder.

2️⃣ Type cd 03_extract (or use cd and the tab key) to get to the third instructional folder.

3️⃣ Type cat 03_readme.txt (or use cat and the tab key) for instructions.