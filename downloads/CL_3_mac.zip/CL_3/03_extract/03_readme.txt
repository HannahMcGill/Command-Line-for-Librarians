🧭 03) — Extract Publication Titles
====================================
🏆 Goal: Build one consolidated list of titles from all downloaded JSON files.

❗In order to complete this next step, you will need to use jq, which is a command line tool for manipulating JSON data. If you have completed the CL_1 project, you will already have jq installed. If you have not yet completed CL_1, please download and complete that project before continuing on; or, simply install jq by typing: brew install jq

1️⃣ Type: cd .. to return to the parent folder.

2️⃣ Run: jq -r '.group[]."work-summary"[].title.title.value' *.json > department_titles.txt

💡 Why: This command extracts the titles of all works from ORCID JSON files and save them as a new file titled department_titles.txt, with one title per line.

❗You do not need to understand how to put together a jq command like this (although you will see the component parts broken down for you so that you can understand the command line as it is written). The goal of using such a like this as a beginner is to understand how command line tools like jq can be useful to you in your work. You can use these sorts of commands to complete a task, even if you could not write them yourself...that is what the internet is for! A quick search can lead you to whatever prompt you might need to preform a task. And so, the purpose of this lesson is to get comfortable using jq commands to preform a task without learning to use each of the component parts individually. 

✨ Tip: If you do want to understand how the command is broken down, here is a breakdown:

👉 jq -r ' tells the command line tool to produce raw output

👉 .group[]."work-summary"[].title.title.value navigates the ORCID JSON structure to find the actual publication title text.

👉 *.json" Applies the command to all JSON files in the directory

👉 > department_titles.txt Indicates that the extracted titles should be saved as a new file titled department_titles.txt

4️⃣ To verify the file exists, type ls and make sure you see department_titles.txt

5️⃣ To verify that the file is populated with titles, type: head -n 10 department_titles.txt

💡 Why: head -n 10 records.json prints the first 10 lines of the file department_titles.txt to the terminal. 

✨ Tip: The head command is used to quickly preview the beginning of a file without opening the whole thing. The -n command indicates how many lines of the file to display.

🚀 TO GET TO THE NEXT LESSON: 

1️⃣ Type cd 04_rank (or use cd and the tab key) to get to the fourth instructional folder.

2️⃣ Type cat 04_readme.txt (or use cat and the tab key) for instructions.
