🧭 01) Prepare
================
🏆 Goal: Make a simple text file with one ORCID iD per line.

1️⃣ Type: cd .. to return to the parent folder.

2️⃣ Type: nano orcid_list.txt

💡 Why: nano is a simple, terminal‑based text editor that lets you create and edit text files directly from the command line.

✨ Tip: Running nano plus a file name (like orcid_list.txt), starts the nano text editor and tells it which file to open. If the file you have named does not exist, nano creates a new file for you to edit.

3️⃣ Enter five ORCIDs, with one id per line by typing directly into the text editor or using copy paste.

⭐ If you would like to use ORCID IDs from researchers at your institution, you can search for those IDs via institutional profile pages, using Institutional Repository records, or by performing a public ORCID search: https://orcid.org/orcid-search/simple. If you just want ORCID IDs to practice with, you can use these:

0000-0001-6614-7783                   
0000-0003-4890-0748
0000-0002-5324-6536
0009-0004-9073-9446
0000-0002-0267-7344 

4️⃣ Type Ctrl + O and then Enter to save your work and write the file to the disk.

5️⃣ Type Ctrl + X to leave the nano editor and return to Terminal.

6️⃣ Verify the file exists by typing ls

7️⃣ Verify the file contains the ORCID IDs you provided by typing: head -n 5 orcid_list.txt
   head -n 5 orcid_list.txt

💡 Why: head is a command that shows just the beginning of a file in Terminal without opening the file in a text editor. Using -n 5 indicates how many lines of the file should be displayed, (in this case, 5 lines) and orcid_list.txt identifies the text file to be read.

✨ Tip: Head is a useful command for previewing large files and checking the formatting without leaving Terminal.

🚀 TO GET TO THE NEXT LESSON:

1️⃣ Type cd 02_download (or use cd and the tab key) to get to the second instructional folder.

3️⃣ Type cat 02_readme.txt (or use cat and the tab key) for instructions.

