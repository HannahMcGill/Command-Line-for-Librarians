🧭 04) Identify Top Journals / Publication Venues
==================================================
🏆 Goal: Create a ranked list of the most frequent journal titles

1️⃣ Type: cd .. to return to the parent folder.

2️⃣ Run: 

jq -r '
  .group[]."work-summary"[]
  | .["journal-title"].value?
' *.json \
| sort | uniq -c | sort -nr | head -10 \
> top_journals.txt


💡 Why: This command line finds all journal titles in the ORCID JSON files, counts how often each journal appears, sorts them by frequency, and saves the top 10 most common journals to top_journals.txt.

❗Once again, you do not need to understand how to put together a jq command like this (although you will see the component parts broken down for you so that you can understand the command line as it is written). The goal of using such a like this as a beginner is to understand how command line tools like jq can be useful to you in your work. You can use these sorts of commands to complete a task, even if you could not write them yourself...that is what the internet is for! A quick search can lead you to whatever prompt you might need to preform a task. And so, the purpose of this lesson is to get comfortable using jq commands to preform a task without learning to use each of the component parts individually. 

✨ Tip: If you do want to understand how the command is broken down, here is a breakdown:

👉 jq -r ' … ' *.json Runs jq on all the ORCID JSON files and outputs the results as plain text (-r), which is easier to work with in later command‑line tools.

👉.group[]."work-summary"[] Ensures every work is processed one by one.

👉 .["journal-title"].value? Extracts the journal title text for each work.

👉 sort | uniq -c | sort -nr | head -10 Processes the extracted journal names

❓ How: 

sort arranges lines of text in alphabetical or numerical order and 
uniq -c → counts how many times each journal appears
sort -nr → orders journals from most to least common
head -10 → keeps only the top 10

👉 > top_journals.txt Writes the final ranked list of journal counts and names into top_journals.txt.

4️⃣ To verify the file exists, type ls and make sure you see top_journals.txt

5️⃣ To read the list of top journals type: cat top_journals.txt (or use cat plus and the tab key).

❗The left column indicates the count of appearances and the right column is the journal name.

🎉🎉🎉 CONGRATULATIONS! 🎉🎉🎉 You’ve completed your a command line project and learned skills that you can reuse and repurpose within the library and beyond!