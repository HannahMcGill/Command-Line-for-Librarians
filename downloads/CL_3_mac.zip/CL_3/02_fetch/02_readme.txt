🧭 02) Query the ORCID API
============================
🏆 Goal: Download each researcher's works record as JSON data.

1️⃣ Type: cd .. to return to the parent folder.

2️⃣ Run a loop (copy & paste as-is):

while read id; do
  curl -s "https://pub.orcid.org/v3.0/$id/works" -H "Accept: application/json" -o "$id.json"
done < orcid_list.txt
 
💡 Why: A loop is a way of automating a command to repeat. Instead of running the same command over and over by hand, a loop tells the shell: “For each item, do this action.” This loop reads each ORCID iD from the orcid_list.txt file, fetches that researcher’s publication data from ORCID as JSON data, saves the data for each researcher as a file named after the ID, and repeats until the list is finished.

❗You do not need to understand how to put together a loop like this at this stage in your learning journey (although you will see the component parts broken down for you so that you can understand the command line as it is written). The goal of using a loop a like this as a beginner is to understand how loops can be useful to you in your work. You can use these sorts of loops to complete a task, even if you could not write them yourself...that is what the internet is for! 

✨ Tip: If you do want to understand how the loop works, here is a breakdown:

👉 "done < orcid_list.txt" Tells the shell to use orcid_list.txt as the the input source, feeding the file into the loop one line at a time

👉 "while read id; do" begins the loop and tells the shell to read one line from the input file and stores that line as the variable id to be used in this iteration of the loop. The variable id is expected to be just one ORCID ID.

👉 "curl -s "https://pub.orcid.org/v3.0/$id/works" queries the ORCID API. Each time the loop runs, $id is replaced with the current ORCID iD and /works for the requests that researcher’s publication list.

👉 "-H "Accept: application/json" asks for JSON data from the API.

👉 "-o "$id.json" Indicates that the JSON data should be saved to a file named after the ORCID ID.

👉 The loop repeats automatically until the query has been run for each ORCID ID.

3️⃣ To verify the files exist, type ls and make sure you see five .json files saved with ORCID IDs as the file names.

🚀 TO GET TO THE NEXT LESSON: 

1️⃣ Type cd 03_extract (or use cd and the tab key) to get to the third instructional folder.

2️⃣ Type cat 03_readme.txt (or use cat and the tab key) for instructions.


