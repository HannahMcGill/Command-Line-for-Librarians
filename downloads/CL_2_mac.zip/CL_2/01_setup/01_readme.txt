🧭  01) Setup 
==============

🏆 Goal: Install the two tools you will need: xsv and ssconvert

❗ To install xsv and ssconvert, you will need to use the MacOS package manager Homebrew. If you have completed the CL_1 project, you will already have Homebrew installed. If you have not yet completed CL_1, please download and complete that project before continuing on. 

💡 Why: A package manager lets you install and manage command‑line tools and software using simple commands. 

✨ Tip: Check to make sure you have Homebrew installed by typing brew --version and looking for something like "Homebrew 5.1.2" that will indicate which version of Homebrew you are running.

1️⃣  Install xsv by typing: brew install xsv

💡 Why: xsv is a fast command-line tool for working with CSV (comma‑separated values) data. It’s designed to make inspecting, transforming, and analyzing CSV files easy and efficient.

✨ Tip: Check to make sure you have xsv installed by typing xsv --version and looking for something like "0.13.0" that will indicate which version of xsv you are running.

2️⃣  Install gnumeric to get access to ssconvert by typing: brew install gnumeric

💡 Why: ssconvert is a command-line tool used to convert spreadsheet files between formats like CSV, XLS, XLSX, and ODS.

✨ Tip: You install gnumeric to use ssconvert because ssconvert is distributed as part of the Gnumeric project (an open‑source spreadsheet software effort). Check to make sure you have ssconvert installed by typing ssconvert --version and looking for something like "ssconvert version '1.12.60" that will indicate which version of ssconvert you are running.

🚀 TO GET TO THE NEXT LESSON:

1️⃣ Type cd .. to return to the parent folder.

2️⃣ Type cd 02_download (or use cd and the tab key) to get to the second instructional folder.

3️⃣ Type cat 02_readme.txt (or use cat and the tab key) for instructions.
