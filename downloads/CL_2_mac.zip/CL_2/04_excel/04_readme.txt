🧭 04) Convert CSV to Excel (.xlsx)
=====================================
🏆 Goal: Convert the CSV file into an Excel spreadsheet.

1️⃣ Type cd .. to return to the parent folder.

2️⃣ Type cd catalogue_project (or use cd and the tab key) to get to the catalogue project folder.

3️⃣ Preview the CSV in a readable table format by typing: xsv table records.csv

💡 Why: xsv table lets you preview your data in a tabular format without opening the file in another program. 

✨ Tip: Just like you might use cat, less, or head to preview a file in Terminal without opening the file using another program, xsv table lets you quickly inspect and understand CSV data by eye without opening a spreadsheet or editor.

4️⃣ Convert the CSV file to an Excel file by typing: ssconvert records.csv records.xlsx

5️⃣ To verify the file exists, type ls and make sure you see records.xlsx

6️⃣ Using the graphical interface (NOT the Command Line) double click on the records.xlsx file to open it in Excel and verify that the data has been moved into the correct rows and columns.

🎉🎉🎉 CONGRATULATIONS! 🎉🎉🎉 You’ve completed a command line project and learned skills that you can reuse and repurpose within the library and beyond!