🧭 03) Extract Useful Fields to CSV
=====================================
🏆 Goal: Convert JSON records into a clean CSV file with useful fields.

❗In order to complete this next step, you will need to use jq, which is a command line tool for manipulating JSON data. If you have completed the CL_1 project, you will already have jq installed. If you have not yet completed CL_1, please download and complete that project before continuing on; or, simply install jq by typing: brew install jq

1️⃣ Type cd .. to return to the parent folder.

2️⃣ Type cd catalogue_project (or use cd and the tab key) to get to the catalogue project folder.

3️⃣ Run:

jq -r '
  .docs[] | [
    .title,
    (.author_name // [] | join("; ")),
    .first_publish_year,
    .edition_count,
    ("https://openlibrary.org" + .key)
  ] | @csv
' records.json > records.csv

💡 Why: This command uses jq to look at each book in the file; extract selected fields (title, authors, publication year, edition count, and a full Open Library URL); format; output clean text suitable for CSV; and writes the result to records.csv.

❗You do not need to understand how to put together a jq command like this (although you will see the component parts broken down for you so that you can understand the command line as it is written). The goal of using a command like this as a beginner is to understand how command line tools like jq can be useful to you in your work. You can use these sorts of commands to complete a task, even if you could not write them yourself...that is what the internet is for! A quick search can lead you to whatever prompt you might need to preform a task. And so, the purpose of this lesson is to get comfortable using jq commands to preform a task without learning to use each of the component parts individually. 

✨ Tip: If you do want to understand how the command is broken down, here is a breakdown:

👉 jq -r ' tells the command line tool to produce raw output, which is required for a CSV file 

👉 '...' Everything inside the single quotation marks is the jq program — the steps jq will take to transform the JSON data

👉 .docs[]  Tells jq to handled the metadata for each book that is listed in the JSON file as a separate entity, rather than treating the whole list as one entity.

👉 [...] The next set of square brackets identifies for jq the information that should be extracted about each book (in this case: author name; year of first publication; number of editions; and, URL) identified as a specific piece of data  

👉 | @csv Converts the data about each book that has been identified into a properly formatted CSV row.

👉 records.json > records.csv Saves the extracted and formatted data as a new file, records.csv

4️⃣ To verify the file exists, type ls and make sure you see records.csv

5️⃣ To verify that the file is populated with CSV data, type: head -n 10 records.csv and make sure you see comma separated values.

🚀 TO GET TO THE NEXT LESSON: 

1️⃣ Type cd .. to return to the parent folder.

2️⃣ Type cd 04_excel (or use cd and the tab key) to get to the fourth instructional folder.

3️⃣ Type cat 04_readme.txt (or use cat and the tab key) for instructions.
