CL_2 Export and Transform Catalogue Records (macOS Edition)
============================================================

👋 Welcome! This self-guided tutorial will teach you command-line essentials as you complete a library-relevant project in 40 minutes or less. 

⭐ Although this project is suitable for command line beginners or anyone looking to refresh their skills, if this is your first time working with command line, please complete the CL_1 project before embarking on CL_2. 

🧰 Project: Download, Export, and Explore Data from an Online Catalogue

This project expands upon the work begun in CL_1 by engaging with different tools to scrape, manipulate, and transform catalogue records.

📚 You'll learn to:

- Install and run software (brewInstall)
- Check for installed software (--version)
- Download data from the web (curl)
- Preview files in Terminal without opening them (head/-n)
- Clean and extract information (jq)
- Create and preview csv files (xsv)
- Convert csv files to Excel files (ssconvert)

🛠️ How this works:

The CL_2 project folder you have downloaded and saved to your Desktop contains 5 folders with instructions. You will use the command line to move through each of the instructional folders in order. 

🏆 Your first goal: Navigate to the CL_2 folder

1️⃣ Open the Terminal app: 🔍 Spotlight Search > Terminal > Enter

2️⃣ Use cd and the tab key to navigate to the CL_2 folder 

💡 Why: cd allows you to navigate around your computer using the command line.

✨ Tip: If you aren't comfortable navigating using cd and cd .. then return to the CL_1 project to review these basics before continuing on.

🚀 TO GET TO THE NEXT LESSON: 

1️⃣ Type cd 01_setup (or use cd and the tab key) to get to the first instructional folder.

2️⃣ Type cat 01_readme.txt (or use cat and the tab key) for instructions.

💡 Why: The cat command shows the contents of a text file in Terminal.

✨ Tip: cat can be used to read any text file you can see within your current location. 
