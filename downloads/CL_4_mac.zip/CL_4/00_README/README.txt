CL_4 Find Controlled Vocabulary Across Databases (macOS Edition)
==================================================================

👋 Welcome! This self-guided tutorial will teach you command-line essentials as you complete a library-relevant project in 40 minutes or less. 

⭐ Although this project is suitable for command line beginners or anyone looking to refresh their skills, if this is your first time working with command line, please complete the CL_1 project before embarking on CL_4. 

🧰 Project: Find controlled vocabulary terms across databases.

This project begins to demonstrate how the command line can enhance search strategy design, particularly for large-scale or scoping reviews.

📚 You'll learn to:

- Fetch JSON data (curl)
- Extract keywords (jq/sort/uniq/sed)
- Preview files (head)
- combine files (cat/>)

🛠️ How this works:

The CL_4 project folder you have downloaded and saved to your Desktop contains 4 folders with instructions. You will use the command line to move through each of the instructional folders in order. 

🏆 Your first goal: Navigate to the CL_4 folder

1️⃣ Open the Terminal app: 🔍 Spotlight Search > Terminal > Enter

2️⃣ Use cd and the tab key to navigate to the CL_4 folder 

💡 Why: cd allows you to navigate around your computer using the command line.

✨ Tip: If you aren't comfortable navigating using cd and cd .. then return to the CL_1 project to review these basics before continuing on.

🚀 TO GET TO THE NEXT LESSON: 

1️⃣ Type cd 01_query_openalex (or use cd and the tab key) to get to the first instructional folder.

2️⃣ Type cat 01_readme.txt (or use cat and the tab key) for instructions.

💡 Why: The cat command shows the contents of a text file in Terminal.

✨ Tip: cat can be used to read any text file you can see within your current location. 
