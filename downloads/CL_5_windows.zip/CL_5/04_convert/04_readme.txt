🧭  04) Convert & Resize Images
======================================
🏆 Goal: Use ImageMagick to Transform Images

1️⃣ Type: cd .. to return to the CL_5 parent folder

2️⃣ Type: cd images (or use cd and the tab key) to navigate to the images folder

3️⃣ Type: magick mogrify -format png *.jpg

💡Why: magick runs the ImageMagick program (which is the main entry point for image processing) and mogrify tells ImageMagick to process multiple images in place or in bulk. -format png specifies that the output image format should be PNG and *.jpg selects all JPG files in the current directory as input.

✨Tip: While we are only converting five files from JPEGs to PNGs, this command would work just as well if you had hundreds or thousands of images to convert.

4️⃣ Type: magick mogrify -resize 1600 *.jpg

💡Why: magick runs the ImageMagick program (which is the main entry point for image processing) and mogrify tells ImageMagick to process multiple images in place or in bulk. -resize 1600 *.jpg selects all JPG files in the images folder as input and resizes them so that they are 1600 pixels wide.

✨Tip: While we are only resizing five JPEGs, this command would work just as well if you had hundreds or thousands of images to convert.

5️⃣ Type: magick identify *.jpg

💡Why: magick runs the ImageMagick program (which is the main entry point for image processing) and identify *.jpg tells ImageMagick to display in Terminal the dimensions of all JPEG files.

✨Tip: Now you can quickly see that you have resized all the JPEG files!

🚀 TO GET TO THE NEXT LESSON: 

1️⃣ Type cd .. to return to the parent folder

2️⃣ Type cd 05_organize (or use cd and the tab key) to get to the fourth instructional folder.

3️⃣ Type cat 05_readme.txt (or use cat and the tab key) for instructions.