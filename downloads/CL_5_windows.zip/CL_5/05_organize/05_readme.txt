🧭 05) Organize Your Image Files
==================================
🏆 Goal: Organize your image files by file type.

1️⃣ Type: cd .. to return to the CL_5 parent folder

2️⃣ Type: cd images (or use cd and the tab key) to navigate to the images folder

3️⃣ Type: mkdir JPEG PNG

💡Why: You can use this command to create two new folders: one called JPEG and one called PNG.

✨Tip: Running mkdir with multiple file names following the command will create as many new folders as you want all at one time.

4️⃣ Type: mv *.png PNG/

💡Why: You can use this command to move all .png files to the PNG folder.

5️⃣ Type: mv *.jpg JPEG/ 

💡Why: You can use this command to move all .jpg files to the JPEG folder.

6️⃣ Confirm that everything is where it should be by checking the file structure. Type:  
tree 2>/dev/null || ls -R

💡 Why: "tree 2>/dev/null || ls -R" tries to show your folder structure in a nice tree format, and if the tree command isn’t available, falls back to ls -R so your project structure is displayed reliably on any system.

✨ Tip: If you have finished the CL_1 project, you may already have tree installed. If not, you can install it in Git Bash using a package manager such as Winget and then simply use the tree command to display the folder structure.

🎉🎉🎉 CONGRATULATIONS! 🎉🎉🎉 You’ve completed a command line project and learned fundamental skills that you can reuse and repurpose within the library and beyond!