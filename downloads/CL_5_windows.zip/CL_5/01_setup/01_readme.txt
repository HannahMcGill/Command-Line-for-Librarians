🧭 01) Setup  
==============

🏆 Goal: Install ImageMagick

❗ To install ImageMagick, you will need to use the Windows package manager Winget. If you have completed the CL_1 project, you will already have Winget available. If you have not yet completed CL_1, please download and complete that project before continuing on. 

💡 Why: A package manager lets you install and manage command‑line tools and software using simple commands. 

✨ Tip: Check to make sure you have Winget installed by typing winget --version and confirming that Winget is available.

1️⃣  Install ImageMagick by typing:  
winget install ImageMagick.ImageMagick

💡 Why: ImageMagick is a powerful command‑line tool for creating, converting, and editing images.

✨ Tip: Check to make sure you have ImageMagick installed by typing magick -version and looking for something like "Version: ImageMagick 7.x.x" that will indicate which version of ImageMagick you are running.

🚀 TO GET TO THE NEXT LESSON:

1️⃣ Type cd .. to return to the parent folder.

2️⃣ Type cd 02_prepare (or use cd and the tab key) to get to the second instructional folder.

3️⃣ Type cat 02_readme.txt (or use cat and the tab key) for instructions.