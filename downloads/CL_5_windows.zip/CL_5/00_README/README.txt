CL_5 Batch Download and Convert Image Files (Windows / Git Bash Edition)
==============================================================

👋 Welcome! This self-guided tutorial will teach you command-line essentials as you complete a library-relevant project in 40 minutes or less. 

⭐ Although this project is suitable for command line beginners or anyone looking to refresh their skills, if this is your first time working with command line, please complete the CL_1 project before embarking on CL_5. 

🧰 Project: Batch download image files and convert file types.

This project begins to demonstrate how the command line can be useful for exhibitions, digital collections, and reporting.

📚 You'll learn to:

- Install and run software (winget)
- Read a text file (cat)
- Check for installed software (--version)
- Create new folders (mkdir)
- Move/rename files (mv)
- Identify all the files and folders in your current location (ls)
- Convert images from one file type to another (magick mogrify -format)
- Resize images (magick mogrify -resize)
- Inspect image files (magick identify)
- Display a clear folder structure (tree)

🛠️ How this works:

The CL_5 project folder you have downloaded and saved to your Desktop contains five folders with instructions. You will use the command line to move through each of the instructional folders in order. 

🏆 Your first goal: Navigate to the CL_5 folder

1️⃣ Open Git Bash:  
🔍 Start Menu Search > Git Bash > Enter

2️⃣ Use cd and the tab key to navigate to the CL_5 folder 

💡 Why: cd allows you to navigate around your computer using the command line.

✨ Tip: If you aren't comfortable navigating using cd and cd .. then return to the CL_1 project to review these basics before continuing on.

🚀 TO GET TO THE NEXT LESSON: 

1️⃣ Type cd 01_setup (or use cd and the tab key) to get to the first instructional folder.

2️⃣ Type cat 01_readme.txt (or use cat and the tab key) for instructions.

💡 Why: The cat command shows the contents of a text file in Terminal.

✨ Tip: cat can be used to read any text file you can see within your current location.
