🧭 04) Compare & Merge Vocabularies
=====================================
🏆 Goal: Combine keywords + MeSH terms.

1️⃣ Combine the author‑supplied keywords and controlled vocabulary by running:  
cat oa_keywords.txt mesh_terms.txt > combined_raw.txt

💡 Why: cat reads the contents of multiple files and sends them as a single stream of text so they can be written into one new file.

✨ Tip: Check to make sure the new file was created by typing ls and looking for combined_raw.txt

2️⃣ Type: sort combined_raw.txt > combined_sorted.txt

💡 Why: sort arranges all terms alphabetically so duplicates end up next to each other and saves the sorted file as combined_sorted.txt

✨ Tip: Check to make sure that sort is working by previewing the document using head -n10 combined_sorted.txt

3️⃣ Type: uniq combined_sorted.txt > combined_terms.txt

💡 Why: uniq keeps only one copy of each term, producing the final cleaned list and saves the sorted file as combined_terms.txt

✨ Tip: Check to make sure that uniq is working by previewing the document using head -n10 combined_terms.txt

🎉🎉🎉 CONGRATULATIONS! 🎉🎉🎉 You’ve completed your command line project and learned skills that you can reuse and repurpose within the library and beyond!