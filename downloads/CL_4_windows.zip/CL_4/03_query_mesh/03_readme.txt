🧭 03) Query MeSH for Controlled Vocabulary
============================================
🏆 Goal: Identify controlled vocabulary related to “climate adaptation.”

1️⃣ Type cd .. to return to the parent folder.

2️⃣ Run:  
curl -s "https://id.nlm.nih.gov/mesh/lookup/term?label=climate&match=contains" \
-o mesh.json

💡 Why: This command sends a request to the MeSH (Medical Subject Headings) API to look up terms related to “climate adaptation” and saves the results as a JSON file.

✨ Tip: To better understand how this command works, let's break it down piece by piece:

👉 curl is command‑line tool that gets data from the internet (think “download something from a URL”)

👉 -s means "silent" and works to hide progress messages so the terminal doesn’t get cluttered.

👉 "https://id.nlm.nih.gov/mesh/lookup/term?label=climate&match=contains" uses an API to query the MeSH database for any official subject terms that contain or resemble the phrase “climate adaptation,” even if it’s not an exact match.

👉 -o mesh.json means “save the result into a file titled mesh.json". Without this part of the command, the data would just appear in the terminal window.

👉 When you put all these pieces together, you end up with a new file in your parent folder titled "mesh.json" that contains matching MeSH terms and identifiers returned by the API.

4️⃣ To check your results, type ls and make sure you see mesh.json.

5️⃣ Extract controlled vocabulary using jq:  
jq -r '.[].label' mesh.json | sed 's/"//g' > mesh_terms.txt

💡 Why: This command extracts the MeSH term labels from the JSON file and saves them as a clean, plain‑text list in mesh_terms.txt.

❗You do not need to understand how to put together a jq command like this (although you will see the component parts broken down for you so that you can understand the command line as it is written). The goal of using such a command like this as a beginner is to understand how command line tools like jq can be useful to you in your work. You can use these sorts of commands to complete a task, even if you could not write them yourself...that is what the internet is for! A quick search can lead you to whatever prompt you might need to perform a task. And so, the purpose of this lesson is to get comfortable using jq commands to perform a task without learning to use each of the component parts individually. 

✨ Tip: If you do want to understand how the command is broken down, here is a breakdown:

👉 jq -r runs jq to read structured data from the file and output the results as raw text, not JSON‑formatted strings.

👉 '.[].label' navigates the JSON array and selects the value of the label field from each item (each MeSH term).

👉 sed 's/"//g' removes any remaining quotation marks from the text to clean it up.

💡 Why: sed automatically finds and alters text.  
✨ Tip: You can think of sed as "find and replace for command line" and use it accordingly.

👉 > mesh_terms.txt saves the extracted list of terms into a new text file called mesh_terms.txt.

6️⃣ To verify the file exists, type ls and make sure you see mesh_terms.txt

7️⃣ To verify that the file is populated with data, type: head -n 10 mesh_terms.txt and make sure you see keywords.

🚀 TO GET TO THE NEXT LESSON: 

1️⃣ Type cd 04_combine (or use cd and the tab key) to get to the fourth instructional folder.

3️⃣ Type cat 04_readme.txt (or use cat and the tab key) for instructions.