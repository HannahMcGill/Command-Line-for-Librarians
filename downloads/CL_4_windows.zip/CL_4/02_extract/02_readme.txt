🧭 02) Extract & Clean Author Keywords
========================================
🏆 Goal: Extract author-supplied keywords and rank them.

❗In order to complete this next step, you will need to use jq, which is a command line tool for manipulating JSON data. If you have completed the CL_1 project, you will already have jq installed. If you have not yet completed CL_1, please download and complete that project before continuing on; or, simply install jq by typing: winget install jqlang.jq

1️⃣ Type cd .. to return to the parent folder.

2️⃣ Run:

jq -r '.results[].keywords[]?.display_name' climate.json \
| sort | uniq -c | sort -nr \
> oa_keywords.txt

💡 Why: The command uses jq to navigate the JSON structure, pulling out each keyword value from the file and outputting it as plain text.

❗You do not need to understand how to put together a jq command like this (although you will see the component parts broken down for you so that you can understand the command line as it is written). The goal of using such a command like this as a beginner is to understand how command line tools like jq can be useful to you in your work. You can use these sorts of commands to complete a task, even if you could not write them yourself...that is what the internet is for! A quick search can lead you to whatever prompt you might need to perform a task. And so, the purpose of this lesson is to get comfortable using jq commands to perform a task without learning to use each of the component parts individually. 

✨ Tip: If you do want to understand how the command is broken down, here is a breakdown:

👉 jq -r '.results[].keywords[]?.display_name' climate.json Uses jq to navigate the JSON structure, pulling out each keyword value from the file and outputting it as plain text. 

👉 sort Sorts the keywords alphabetically so identical ones are grouped together.

💡 Why: sort is for sorting text alphabetically or numerically.  
✨ Tip: You can use sort to manipulate text using the command line.

👉 uniq -c | sort -nr Counts how many times each keyword appears and then sorts them from most frequent to least frequent.

💡 Why: uniq removes duplicate lines so each line appears only once.  
✨ Tip: You can use uniq (usually after sort) to count or eliminate repeated entries in a list.

👉 > oa_keywords.txt Saves the ranked list of keyword counts as a text file called oa_keywords.txt.

4️⃣ To verify the file exists, type ls and make sure you see oa_keywords.txt

5️⃣ To verify that the file is populated with data, type: head -n 10 oa_keywords.txt and make sure you see keywords.

🚀 TO GET TO THE NEXT LESSON: 

1️⃣ Type cd 03_query_mesh (or use cd and the tab key) to get to the third instructional folder.

3️⃣ Type cat 03_readme.txt (or use cat and the tab key) for instructions.