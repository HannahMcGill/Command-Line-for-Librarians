🧭 01) Prepare
================
🏆 Goal: Make a simple text file with one ORCID iD per line.

1️⃣ Type: cd .. to return to the parent folder.

2️⃣ Type: vim orcid_list.txt

💡 Why: vim is a terminal‑based text editor that lets you create and edit text files directly from the command line.

✨ Tip: Running vim plus a file name (like orcid_list.txt) starts the vim text editor and tells it which file to open. If the file you have named does not exist, vim creates a new file for you to edit.

3️⃣ Enter five ORCIDs, with one id per line by typing directly into the text editor or using copy paste.

⭐ If you would like to use ORCID IDs from researchers at your institution, you can search for those IDs via institutional profile pages, using Institutional Repository records, or by performing a public ORCID search: https://orcid.org/orcid-search/simple. If you just want ORCID IDs to practice with, you can use these:

0000-0001-6614-7783                   
0000-0003-4890-0748
0000-0002-5324-6536
0009-0004-9073-9446
0000-0002-0267-7344 

4️⃣ Press i to enter insert mode (you will see text appear at the bottom of the screen), then copy and paste the ORCID IDs provided above or enter your own text.

5️⃣ When you are done typing, press Esc to return to command mode. THEN, type :wq and press Enter to save your work and exit vim.

💡 Why: Vim has different modes, and you must return to command mode before you can save and exit. Pressing Esc ensures Vim knows you are done editing, and typing :wq tells Vim to write the file to disk and quit safely.

✨ Tip: If you ever see Vim “not responding,” it usually means you are still in insert mode—press Esc first, then try :wq again. This is the most common Vim issue for beginners and is easy to fix once you know it.

6️⃣ Verify the file exists by typing ls

7️⃣ Verify the file contains the ORCID IDs you provided by typing: head -n 5 orcid_list.txt
   head -n 5 orcid_list.txt

💡 Why: head is a command that shows just the beginning of a file in Terminal without opening the file in a text editor. Using -n 5 indicates how many lines of the file should be displayed, (in this case, 5 lines) and orcid_list.txt identifies the text file to be read.

✨ Tip: Head is a useful command for previewing large files and checking the formatting without leaving Terminal.

🚀 TO GET TO THE NEXT LESSON:

1️⃣ Type cd 02_download (or use cd and the tab key) to get to the second instructional folder.

3️⃣ Type cat 02_readme.txt (or use cat and the tab key) for instructions.
