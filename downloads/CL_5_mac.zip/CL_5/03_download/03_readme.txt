🧭 03) Batch Download Images
==============================
🏆 Goal: Use a single Command Line Loop to Batch Download Images

1️⃣ Type cd .. to return to the CL_5 parent folder

2️⃣ Type mkdir images

💡Why: mkdir means "make directory". You can use this command to create a new folder that will be called whatever name you indicate after the mkdir command (in this case "images").

✨Tip: Running mkdir will create a new folder that will be located wherever you are when you input the command. We want the research project folder to be located in the CL_5 parent folder, which is why we used cd .. to navigate to CL_5 before running the mkdir command.

3️⃣ Type: ls

💡 Why: ls means "list what's here" and shows you all the files and folders in your current location.

✨Tip: Use ls to confirm that you have successfully created a folder with the name images

4️⃣ Type: mv images_list.txt images/

💡 Why: mv means "move" and will relocate the text file named images_list.txt to the new images folder.

✨ Tip: mv can be used to move files or folders around your computer. To move a file or folder into a new folder type: mv filename newfoldername/

5️⃣ Type: cd images (or use cd and the tab key) to navigate to the images folder

6️⃣ Run a loop (copy & paste as-is):

  while read url; do
      curl -L -O "$url"
  done < images_list.txt

💡 Why: A loop is a way of automating a command to repeat. Instead of running the same command over and over by hand, a loop tells the shell: “For each item, do this action.” This loop reads each URL from images_list.txt one line at a time and downloads the corresponding file to the images folder.

❗You do not need to understand how to put together a loop like this at this stage in your learning journey (although you will see the component parts broken down for you so that you can understand the command line as it is written). The goal of using a loop a like this as a beginner is to understand how loops can be useful to you in your work. You can use these sorts of loops to complete a task, even if you could not write them yourself...that is what the internet is for! 

✨ Tip: If you do want to understand how the loop works, here is a breakdown:

👉 done < images_list.txt Tells the shell to use images_list.txt as input, feeding the file into the loop one line at a time.

👉 while read url; do Starts a loop that reads one line at a time from the input file and stores that line in the variable url. \

👉 curl -L "$url" Uses curl to download the file from the URL and -L follows redirects, which are common for image hosting sites. The loop continues downloading images one URL at a time until every line in images_list.txt has been processed.

👉 -O Tells curl to save the file using its original filename from the URL, instead of printing it to the terminal.

7️⃣ Type ls

💡 Why: ls means "list what's here" and shows you all the files and folders in your current location.

✨Tip: Use ls to confirm that you have successfully downloaded all five .jpg files to the images folder. 


🚀 TO GET TO THE NEXT LESSON: 

1️⃣ Type cd .. to return to the parent folder

2️⃣ Type cd 04_convert (or use cd and the tab key) to get to the fourth instructional folder.

3️⃣ Type cat 04_readme.txt (or use cat and the tab key) for instructions.
