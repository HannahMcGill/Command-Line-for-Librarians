🧭  02) Prepare Your URL List
===========================
🏆 Goal: Review a text file

1️⃣ Type cd .. to return to the parent folder.

2️⃣ Type cat images_list.txt (or use cat and the tab key)

💡 Why: The cat command shows the contents of a text file in Terminal.

✨ Tip: cat can be used to read any text file you can see within your current location. For a list of the files available to you to read at any time, use ls

3️⃣ Inspect the text displayed in Terminal to ensure that you are seeing a list of five URLs, with one URL appearing on each line.

💡 Why: These URLs point to the images you will download.

✨ Tip: For now, we are only downloading five images, but this list could contain thousands and thousands of URLs and the same process we will follow would work just as efficiently.

🚀 TO GET TO THE NEXT LESSON:

1️⃣ Type cd 03_download (or use cd and the tab key) to get to the second instructional folder.

2️⃣ Type cat 03_readme.txt (or use cat and the tab key) for instructions.